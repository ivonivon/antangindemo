
$(function () {
    $.srSmoothscroll();
});
